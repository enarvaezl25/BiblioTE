<script src="<?php echo SERVERURL; ?>vistas/js/jquery-3.1.1.min.js"></script>
<script src="<?php echo SERVERURL; ?>vistas/js/sweetalert2.min.js"></script>
<script src="<?php echo SERVERURL; ?>vistas/js/bootstrap.min.js"></script>
<script src="<?php echo SERVERURL; ?>vistas/js/material.min.js"></script>
<script src="<?php echo SERVERURL; ?>vistas/js/ripples.min.js"></script>
<script src="<?php echo SERVERURL; ?>vistas/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo SERVERURL; ?>vistas/js/main.js"></script>

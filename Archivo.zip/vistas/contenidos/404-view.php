<div class="full-box cover container-404">
	<div>
		<p class="text-center"><i class="zmdi zmdi-mood-bad zmdi-hc-5x"></i></p>
		<h1 class="text-center">ERROR 404</h1>
		<p class="lead text-center">Página no encontrada</p>
	</div>
</div>
<?php
	
	/*----------  Datos del servidor  ----------*/
	const SERVER="localhost";
	const DB="BibliotecaVirtualTE";
	const USER="root";
	const PASS="";


	const SGBD="mysql:host=".SERVER.";dbname=".DB;


	/*----------  Datos de la encriptacion ----------*/
	const METHOD="AES-256-CBC";
	const SECRET_KEY='$BP@2017';
	const SECRET_IV='101712';
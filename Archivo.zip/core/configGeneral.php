<?php
	/*----------  Ruta o dominio del servidor  ----------*/
	const SERVERURL="http://localhost/SBV/";

	/*----------  Nombre de la empresa o compañia  ----------*/
	const COMPANY="SISTEMA BIBLIOTECA";

	/*----------  Zona horaria  ----------*/
	date_default_timezone_set ("America/Managua");

	/*
		Configuración de zona horaria del  país para más información visita
		http://php.net/manual/es/function.date-default-timezone-set.php
		http://php.net/manual/es/timezones.php
	*/